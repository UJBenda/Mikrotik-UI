"""Načítání konfigurace z config.toml s přepisem z prostředí.

Pořadí: výchozí hodnoty < config.toml < proměnné MTC_<SEKCE>__<KLÍČ>.
Cesta ke config.toml: $MTC_CONFIG, jinak /etc/mtcontroller/config.toml.
"""

from __future__ import annotations

import ipaddress
import json
import os
import re
import tomllib
from functools import lru_cache
from pathlib import Path
from typing import Any, Mapping

from pydantic import BaseModel, Field, field_validator, model_validator

DEFAULT_CONFIG_PATH = Path("/etc/mtcontroller/config.toml")
ENV_PREFIX = "MTC_"
_HOST = re.compile(r"^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)*$")


def _hostname(v: str) -> str:
    v = v.strip().lower()
    if not _HOST.match(v):
        raise ValueError(f"neplatný hostname: {v!r}")
    return v


class DatabaseConfig(BaseModel):
    # libpq conninfo; přes unix socket a peer autentizaci (bez hesla po síti)
    dsn: str = "dbname=mtcontroller user=mtc_app host=/run/postgresql"
    migrate_dsn: str = "dbname=mtcontroller user=mtc_owner host=/run/postgresql"
    app_role: str = "mtc_app"


class WebConfig(BaseModel):
    listen_host: str = "127.0.0.1"
    listen_port: int = 8080
    ui_host: str = "localhost"
    checkin_host: str = "localhost"
    session_hours: int = Field(default=8, ge=1, le=24)

    @field_validator("ui_host", "checkin_host")
    @classmethod
    def check_hosts(cls, v: str) -> str:
        return _hostname(v)


class SecurityConfig(BaseModel):
    master_key_file: Path = Path("/etc/mtcontroller/master.key")
    adoption_token_ttl_minutes: int = Field(default=60, ge=5, le=24 * 60)
    # RouterOS fetch: "yes-without-crl" (doporučeno), "yes", nebo "no" jen pro laboratoř
    device_check_certificate: str = "yes-without-crl"
    # vlastní CA controlleru (lokální režim / bez Let's Encrypt): PEM, který si zařízení stáhne
    # z http://<checkin_host>/mtc-ca.crt a ponechá jen při shodě otisku; prázdné = veřejná CA
    device_ca_file: Path | None = None
    # moduly, jejichž plány musí schválit jiný uživatel než autor
    # sítě, Wi-Fi a porty řízených zařízení se nasazují hned po uložení (s automatickým návratem);
    # modul přidaný sem (např. "switch", "capsman") pak čeká na schválení druhým správcem
    four_eyes_modules: list[str] = Field(default_factory=lambda: ["firewall"])

    @field_validator("device_check_certificate")
    @classmethod
    def _cc(cls, v: str) -> str:
        if v not in {"yes", "yes-without-crl", "no"}:
            raise ValueError("device_check_certificate: yes | yes-without-crl | no")
        return v


class PathsConfig(BaseModel):
    data_dir: Path = Path("/var/lib/mtcontroller")


class ConcentratorConfig(BaseModel):
    name: str
    # hostname, na který se připojují SSTP klienti (musí sedět s certifikátem SSTP serveru)
    connect_host: str
    # REST API koncentrátoru z pohledu controlleru, např. https://10.10.0.1:8443 (443 patří SSTP)
    api_url: str
    api_user: str = "mtc-controller"
    api_password_file: Path
    # SHA-256 otisk certifikátu www-ssl koncentrátoru (pinning), hex bez dvojteček
    api_fingerprint: str
    # brána na tunely v síti controlleru (pro tunnel.manage_routes); výchozí = host z api_url
    route_via: str | None = None

    @field_validator("route_via")
    @classmethod
    def _route_via(cls, v: str | None) -> str | None:
        return str(ipaddress.ip_address(v)) if v else None

    @field_validator("connect_host")
    @classmethod
    def check_connect_host(cls, v: str) -> str:
        return _hostname(v)

    @field_validator("api_url")
    @classmethod
    def _https(cls, v: str) -> str:
        if not v.startswith("https://"):
            raise ValueError("api_url musí být https://")
        return v.rstrip("/")

    @field_validator("api_fingerprint")
    @classmethod
    def _fp(cls, v: str) -> str:
        v = v.replace(":", "").strip().lower()
        if not re.fullmatch(r"[0-9a-f]{64}", v):
            raise ValueError("api_fingerprint musí být SHA-256 (64 hex znaků)")
        return v

    def password(self) -> str:
        return self.api_password_file.read_text().strip()


class TunnelConfig(BaseModel):
    # "mikrotik" = vzdálená správa přes SSTP koncentrátory; "none" = lokální režim
    # (controller ve stejné síti, správa zařízení přímo na jejich LAN adresu, bez tunelů)
    provider: str = "mikrotik"
    pool: str = "10.200.0.0/16"
    tenant_block_prefix: int = 24
    # adresa controlleru, ze které chodí správa do tunelů (zařízení ji vidí jako zdroj)
    controller_ip: str = "10.10.0.10"
    concentrators: list[ConcentratorConfig] = Field(default_factory=list)
    # worker udržuje routy /32 na zařízení přes koncentrátor, ke kterému jsou
    # připojená (failover mezi koncentrátory); potřebuje CAP_NET_ADMIN
    manage_routes: bool = False

    @field_validator("provider")
    @classmethod
    def _provider(cls, v: str) -> str:
        if v not in {"mikrotik", "radius", "none"}:
            raise ValueError("tunnel.provider musí být 'mikrotik', 'radius' nebo 'none' (lokální režim)")
        return v

    @property
    def local(self) -> bool:
        """Lokální režim: žádné tunely, správa přímo na adresu, ze které se zařízení hlásí."""
        return self.provider == "none"

    @field_validator("pool")
    @classmethod
    def _pool(cls, v: str) -> str:
        net = ipaddress.ip_network(v, strict=True)
        if not net.is_private:
            raise ValueError("tunnel.pool musí být privátní rozsah")
        return str(net)

    @field_validator("controller_ip")
    @classmethod
    def _cip(cls, v: str) -> str:
        return str(ipaddress.ip_address(v))

    @model_validator(mode="after")
    def _controller_outside_pool(self) -> "TunnelConfig":
        if self.local:
            if self.concentrators:
                raise ValueError("lokální režim (tunnel.provider = 'none') nepoužívá koncentrátory")
            if self.manage_routes:
                raise ValueError("lokální režim nemá tunely – tunnel.manage_routes musí být false")
            return self
        if ipaddress.ip_address(self.controller_ip) in ipaddress.ip_network(self.pool):
            raise ValueError("controller_ip nesmí ležet v tunelovém poolu")
        names = [c.name for c in self.concentrators]
        if len(names) != len(set(names)):
            raise ValueError("jména koncentrátorů musí být unikátní")
        return self


class NotifyTarget(BaseModel):
    name: str
    # "nextcloud_talk" (bot Talk), "json" (obecný webhook s HMAC podpisem) nebo "email"
    kind: str = "json"
    # webhook: https://…; email: smtps://uživatel@server:465 nebo smtp://uživatel@server:587 (STARTTLS povinně)
    url: str
    # webhook: tajemství podpisu; email: heslo k SMTP (prázdné = bez přihlášení)
    secret_file: Path
    min_severity: str = "warning"
    # prázdné = všichni tenanti; jinak seznam UUID tenantů
    tenants: list[str] = Field(default_factory=list)
    # jen email
    mail_from: str = ""
    mail_to: list[str] = Field(default_factory=list)

    @field_validator("kind")
    @classmethod
    def _kind(cls, v: str) -> str:
        if v not in {"nextcloud_talk", "json", "email"}:
            raise ValueError("notify.kind: nextcloud_talk | json | email")
        return v

    @model_validator(mode="after")
    def _email(self) -> "NotifyTarget":
        if self.kind == "email":
            if not self.mail_from or not self.mail_to:
                raise ValueError("notify (email): vyplň mail_from a mail_to")
            for a in [self.mail_from, *self.mail_to]:
                if not re.fullmatch(r"[^@\s<>,;]+@[^@\s<>,;]+\.[^@\s<>,;]+", a):
                    raise ValueError(f"notify (email): neplatná adresa {a!r}")
        return self

    @field_validator("min_severity")
    @classmethod
    def _sev(cls, v: str) -> str:
        if v not in {"info", "warning", "critical"}:
            raise ValueError("notify.min_severity: info | warning | critical")
        return v

    @field_validator("url")
    @classmethod
    def _url(cls, v: str) -> str:
        if not v.startswith(("https://", "smtps://", "smtp://")):
            raise ValueError("notify.url musí být https:// (webhook) nebo smtps:// / smtp:// (email)")
        return v

    @model_validator(mode="after")
    def _url_kind(self) -> "NotifyTarget":
        is_mail = self.url.startswith(("smtps://", "smtp://"))
        if is_mail != (self.kind == "email"):
            raise ValueError("notify: email potřebuje url smtps:// nebo smtp://, webhooky https://")
        return self

    def secret(self) -> str:
        return self.secret_file.read_text().strip()


class FlowConfig(BaseModel):
    """Příjem NetFlow v9 / IPFIX z bran (UDP přes tunel; běží ve službě mtc-syslog)."""
    port: int = 2055
    # adresa, na které služba poslouchá; prázdné = tunnel.controller_ip
    listen: str = ""
    retention_days: int = 30
    # pojistka proti zahlcení: víc datagramů za minutu od jednoho zařízení se zahodí
    max_packets_per_minute: int = 6000
    # kolik různých řádků (klient × protistrana × služba) si nechat na bránu a hodinu; zbytek jde do „ostatní“
    max_rows_per_hour: int = 500

    @field_validator("port")
    @classmethod
    def _port(cls, v: int) -> int:
        if not 1024 <= v <= 65535:
            raise ValueError("flow.port: 1024–65535 (služba neběží jako root)")
        return v

    @field_validator("retention_days")
    @classmethod
    def _ret(cls, v: int) -> int:
        if not 1 <= v <= 365:
            raise ValueError("flow.retention_days: 1–365")
        return v

    @field_validator("max_rows_per_hour")
    @classmethod
    def _rows(cls, v: int) -> int:
        if not 20 <= v <= 20000:
            raise ValueError("flow.max_rows_per_hour: 20–20000")
        return v


class SyslogConfig(BaseModel):
    """Příjem logů ze zařízení (UDP syslog přes tunel; služba mtc-syslog)."""
    port: int = 5514
    # adresa, na které služba poslouchá; prázdné = tunnel.controller_ip
    listen: str = ""
    retention_days: int = 14
    # pojistka proti zahlcení: víc řádků za minutu od jednoho zařízení se zahodí (a započítá)
    max_lines_per_minute: int = 600
    # volitelně přeposlat (UDP syslog) dál, např. do SIEM: "host:port"
    forward: str = ""

    @field_validator("port")
    @classmethod
    def _port(cls, v: int) -> int:
        if not 1024 <= v <= 65535:
            raise ValueError("syslog.port: 1024–65535 (služba neběží jako root)")
        return v

    @field_validator("retention_days")
    @classmethod
    def _ret(cls, v: int) -> int:
        if not 1 <= v <= 365:
            raise ValueError("syslog.retention_days: 1–365")
        return v

    @field_validator("forward")
    @classmethod
    def _fwd(cls, v: str) -> str:
        if v and not re.fullmatch(r"[A-Za-z0-9.:\[\]-]+:\d{1,5}", v):
            raise ValueError("syslog.forward: host:port")
        return v


_TZ = re.compile(r"^[A-Za-z_]+(/[A-Za-z0-9_+-]+){0,2}$")
_COUNTRY = re.compile(r"^[A-Za-z][A-Za-z .'-]{1,39}$")


class SiteDefaults(BaseModel):
    """Výchozí hodnoty pro lokality a výchozí konfiguraci zařízení (nastaví průvodce)."""
    timezone: str = "Europe/Prague"
    # země pro regulaci Wi-Fi – jméno, jak ho zná RouterOS (/interface wifi … country=)
    country: str = "Czech Republic"
    ntp: list[str] = Field(default_factory=lambda: ["tik.cesnet.cz", "tak.cesnet.cz"])

    @field_validator("timezone")
    @classmethod
    def _tz(cls, v: str) -> str:
        if not _TZ.match(v):
            raise ValueError("site_defaults.timezone: např. Europe/Prague")
        return v

    @field_validator("country")
    @classmethod
    def _country(cls, v: str) -> str:
        if not _COUNTRY.match(v):
            raise ValueError("site_defaults.country: jméno země pro RouterOS, např. Czech Republic")
        return v

    @field_validator("ntp")
    @classmethod
    def _ntp(cls, v: list[str]) -> list[str]:
        if not 1 <= len(v) <= 4:
            raise ValueError("site_defaults.ntp: 1–4 servery")
        return [_hostname(h) for h in v]


class BackupConfig(BaseModel):
    """Zálohy controlleru (DB + konfigurace + klíče), šifrované heslem zálohy."""
    dir: Path = Path("/var/backups/mtcontroller")
    keep: int = Field(default=14, ge=1, le=365)
    passphrase_file: Path = Path("/etc/mtcontroller/backup.key")


class Settings(BaseModel):
    database: DatabaseConfig = Field(default_factory=DatabaseConfig)
    web: WebConfig = Field(default_factory=WebConfig)
    security: SecurityConfig = Field(default_factory=SecurityConfig)
    paths: PathsConfig = Field(default_factory=PathsConfig)
    tunnel: TunnelConfig = Field(default_factory=TunnelConfig)
    notify: list[NotifyTarget] = Field(default_factory=list)
    syslog: SyslogConfig = Field(default_factory=SyslogConfig)
    flow: FlowConfig = Field(default_factory=FlowConfig)
    site_defaults: SiteDefaults = Field(default_factory=SiteDefaults)
    backup: BackupConfig = Field(default_factory=BackupConfig)


def _env_overrides(environ: Mapping[str, str]) -> dict[str, dict[str, Any]]:
    out: dict[str, dict[str, Any]] = {}
    for key, raw in environ.items():
        if not key.startswith(ENV_PREFIX) or "__" not in key or key == "MTC_CONFIG":
            continue
        section, _, field = key[len(ENV_PREFIX):].partition("__")
        value: Any = raw
        if raw[:1] in "[{":
            value = json.loads(raw)
        out.setdefault(section.lower(), {})[field.lower()] = value
    return out


def load_settings(
    path: Path | None = None, environ: Mapping[str, str] | None = None
) -> Settings:
    environ = os.environ if environ is None else environ
    path = path or Path(environ.get("MTC_CONFIG", DEFAULT_CONFIG_PATH))
    data: dict[str, dict[str, Any]] = {}
    if path.exists():
        with path.open("rb") as fh:
            data = tomllib.load(fh)
    for section, values in _env_overrides(environ).items():
        data.setdefault(section, {}).update(values)
    return Settings.model_validate(data)


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return load_settings()
