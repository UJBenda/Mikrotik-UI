"""Administrační příkazy: `python3 -m mtcontroller.cli <příkaz>` (alias `mtc-admin`).

  migrate                       aplikuje migrace (spouští root, role mtc_owner)
  gen-master-key                vypíše nový master klíč (base64)
  create-superadmin EMAIL       založí superadmina (heslo interaktivně)
  create-user EMAIL ROLE TENANT založí uživatele s rolí v tenantovi
  create-tenant NAME            založí tenanta (přidělí tunelový blok)
  create-site TENANT NAME       založí lokalitu
  token TENANT [SITE]           vygeneruje adopční příkaz pro MikroTik
  devices TENANT                vypíše zařízení
  approve TENANT DEVICE SITE    schválí zařízení
  concentrator-script NAME      vypíše .rsc pro nastavení koncentrátoru
  concentrator-check            ověří REST spojení na všechny koncentrátory
  notify-test NAME              pošle zkušební notifikaci na cíl z [[notify]]
  doctor                        zkontroluje instalaci (konfigurace, DB, síť, koncentrátory)
  device-check TENANT DEVICE    diagnostika REST přes tunel (identita, otisk, porty, aktualizace)
  setup-code                    vypíše kód webového průvodce prvního spuštění (root)
  setup-apply                   provede nastavení z průvodce (root; spouští mtc-setup-apply.path)
  backup                        šifrovaná záloha controlleru (root; timer mtc-backup a žádost z UI)
  restore SOUBOR [--force]      obnova controlleru ze zálohy .mtcbak (root; zastaví služby)
  restore SOUBOR --check        jen posoudí zálohu (verze, migrace, PostgreSQL, adresy) – nic nezmění
  recovery-kit                  vypíše záchranné údaje (heslo záloh, DB, cesty) (root)
  tls [status|own|letsencrypt EMAIL|custom CERT KEY|bootstrap] [--slot admin|checkin]
                                certifikát HTTPS pro nginx (root; jinak Systém → Certifikát HTTPS)
  nginx-repair                  konfigurace nginx znovu z plánu průvodce (instalace balíčkem)
  tls-apply                     provede žádost o certifikát z UI (root; spouští mtc-tls.path)
  tls-sync                      deploy hook certbotu: obnovený Let's Encrypt do nginx (root)
"""

from __future__ import annotations

import argparse
import getpass
import json
import re
import sys

from . import __version__
from .config import get_settings


def _db():
    from .db import get_db
    return get_db()


def _password() -> str:
    pw = getpass.getpass("Heslo (min. 12 znaků): ")
    if pw != getpass.getpass("Znovu: "):
        raise SystemExit("Hesla se neshodují")
    return pw


def _tenant_id(ref: str) -> str:
    from .db import operator_scope
    with operator_scope(_db()) as tx:
        row = tx.fetchone("SELECT id FROM tenant WHERE id::text = %(r)s OR name = %(r)s", {"r": ref})
    if not row:
        raise SystemExit(f"tenant {ref!r} neexistuje")
    return str(row["id"])


def _site_id(tenant_id: str, ref: str) -> str:
    from .db import tenant_scope
    with tenant_scope(_db(), tenant_id) as tx:
        row = tx.fetchone("SELECT id FROM site WHERE id::text = %(r)s OR name = %(r)s", {"r": ref})
    if not row:
        raise SystemExit(f"lokalita {ref!r} neexistuje")
    return str(row["id"])


def cmd_migrate(a) -> int:
    from . import migrate
    from .db import PsycopgDatabase
    s = get_settings()
    ran = migrate.upgrade(PsycopgDatabase(s.database.migrate_dsn), s.database.app_role)
    print("aplikováno:", ran or "nic, schéma je aktuální")
    return 0


def cmd_gen_master_key(a) -> int:
    from .security import SecretBox
    print(SecretBox.generate_master_key())
    return 0


def cmd_create_superadmin(a) -> int:
    from . import auth
    from .db import operator_scope
    from .services import audit
    pw = _password()
    with operator_scope(_db()) as tx:
        uid = auth.create_user(tx, a.email, pw)
        tx.execute("INSERT INTO role_binding (user_id, role) VALUES (%(u)s, 'superadmin')", {"u": uid})
        audit(tx, "user.create_superadmin", target=f"user:{uid}", after={"email": a.email.lower()})
    print(f"Superadmin {a.email} založen. MFA se nastaví při prvním přihlášení v UI.")
    return 0


def cmd_create_user(a) -> int:
    from . import auth
    from .db import operator_scope
    from .services import audit
    if a.role not in ("tenant_admin", "technician", "readonly"):
        raise SystemExit("role: tenant_admin | technician | readonly")
    tid = _tenant_id(a.tenant)
    pw = _password()
    with operator_scope(_db()) as tx:
        uid = auth.create_user(tx, a.email, pw)
        tx.execute("INSERT INTO role_binding (user_id, role, tenant_id) VALUES (%(u)s, %(r)s, %(t)s)",
                   {"u": uid, "r": a.role, "t": tid})
        audit(tx, "user.create", tenant_id=tid, target=f"user:{uid}", after={"email": a.email.lower(), "role": a.role})
    print(f"Uživatel {a.email} ({a.role}) založen.")
    return 0


def cmd_create_tenant(a) -> int:
    from .services import create_tenant
    row = create_tenant(_db(), get_settings(), a.name)
    print(f"Tenant {row['name']} založen: id={row['id']} blok={row['tunnel_block']}")
    return 0


def cmd_create_site(a) -> int:
    from .services import create_site
    row = create_site(_db(), _tenant_id(a.tenant), a.name)
    print(f"Lokalita {row['name']} založena: id={row['id']}")
    return 0


def cmd_token(a) -> int:
    from .db import operator_scope
    from .services import create_adoption_token
    tid = _tenant_id(a.tenant)
    sid = _site_id(tid, a.site) if a.site else None
    with operator_scope(_db()) as tx:
        u = tx.fetchone("""SELECT u.id FROM app_user u JOIN role_binding r ON r.user_id = u.id
                           WHERE r.role = 'superadmin' ORDER BY u.created_at LIMIT 1""")
    if not u:
        raise SystemExit("nejdřív založ superadmina (create-superadmin)")
    out = create_adoption_token(_db(), get_settings(), tid, sid, u["id"])
    print(f"Platí do {out.expires_at}, jednorázově. Vlož do terminálu MikroTiku:\n")
    print(out.command)
    return 0


def cmd_devices(a) -> int:
    from .db import tenant_scope
    tid = _tenant_id(a.tenant)
    with tenant_scope(_db(), tid) as tx:
        rows = tx.fetchall("""SELECT d.id, d.serial, d.model, d.ros_version, d.state, host(d.tunnel_ip) AS ip,
                                     s.name AS site, d.last_checkin_at, d.last_status->>'sstp' AS sstp
                              FROM device d LEFT JOIN site s ON s.id = d.site_id ORDER BY d.created_at""")
    for r in rows:
        print(f"{r['id']}  {r['state']:<12} {r['serial']:<16} {r['model'] or '':<20} {r['ros_version'] or '':<18} "
              f"{r['site'] or '-':<12} {r['ip'] or '-':<14} sstp={r['sstp'] or '-'}  checkin={r['last_checkin_at']}")
    return 0


def device_check(db, box, tid: str, ref: str, out=print) -> int:
    """Diagnostika REST přes tunel: identita, otisk certifikátu, monitor portů, aktualizace."""
    from . import inventory
    from .db import tenant_scope
    from .rosapi import PinMismatch, RosApiError
    from .services import device_api

    with tenant_scope(db, tid) as tx:
        dev = tx.fetchone("""SELECT id, serial, state, host(tunnel_ip) AS tunnel_ip, api_cert_fingerprint AS fp
                             FROM device WHERE id::text = %(r)s OR serial = %(r)s""", {"r": ref})
        if not dev:
            raise SystemExit(f"zařízení {ref!r} neexistuje")
        out(f"{dev['serial']}: stav {dev['state']}, tunel {dev['tunnel_ip'] or '-'}, otisk {dev['fp'] or '-'}")
        try:
            api = device_api(tx, box, dev, timeout=15)
        except Exception as e:  # noqa: BLE001
            out(f"  [XX] {e}")
            return 1
    ok = True
    checks = [
        ("identita", lambda: api.get("/system/identity").get("name")),
        ("verze", lambda: api.get("/system/resource").get("version")),
        ("ethernet monitor", lambda: ", ".join(
            f"{m.get('name')}={m.get('rate') or m.get('status')}" for m in (api.post(
                "/interface/ethernet/monitor",
                {"numbers": ",".join(e["name"] for e in api.get("/interface/ethernet", **{".proplist": "name"})[:4]),
                 "once": "true", ".proplist": inventory.MONITOR_PROPS}) or []))),
        ("aktualizace", lambda: str(api.get("/system/package/update"))),
    ]
    try:
        for name, fn in checks:
            try:
                out(f"  [OK] {name}: {fn()}")
            except PinMismatch:
                raise
            except RosApiError as e:
                ok = False
                out(f"  [XX] {name}: {e}")
    except PinMismatch as e:
        out(f"  [XX] otisk certifikátu: {e}")
        return 1
    finally:
        api.close()
    return 0 if ok else 1


def cmd_device_trust(a) -> int:
    """Příkaz pro terminál zařízení, které přestalo věřit check-inu (nová CA controlleru)."""
    from . import routeros
    opts = routeros.fetch_opts(get_settings())
    body = routeros.trust_ca_body(opts)
    if not body:
        raise SystemExit("controller nepoužívá vlastní CA pro zařízení (security.device_ca_file) – není co dosazovat")
    print("# vlož do terminálu RouterOS (CA se stáhne přes HTTP a ponechá jen při shodě otisku):")
    print("{ " + routeros._one_line(body) + " }")
    print(f"# otisk CA: {opts.ca_fp}")
    return 0


def cmd_device_check(a) -> int:
    from .security import get_box
    return device_check(_db(), get_box(), _tenant_id(a.tenant), a.device)


def cmd_approve(a) -> int:
    from .security import get_box
    from .services import approve_device
    from .tunnel import build_providers
    s = get_settings()
    tid = _tenant_id(a.tenant)
    errors = approve_device(_db(), s, get_box(), build_providers(s), tid, a.device,
                            _site_id(tid, a.site), a.role)
    print("Schváleno. Provisioning proběhne při dalším check-inu (do 1 min).")
    for e in errors:
        print("VAROVÁNÍ koncentrátor:", e, file=sys.stderr)
    return 0


def cmd_concentrator_script(a) -> int:
    from .concentrator import concentrator_script
    s = get_settings()
    c = next((c for c in s.tunnel.concentrators if c.name == a.name), None)
    if not c:
        raise SystemExit(f"koncentrátor {a.name!r} není v konfiguraci")
    print(concentrator_script(s, c, c.password()))
    return 0


def cmd_concentrator_check(a) -> int:
    from .tunnel import build_providers
    ok = True
    for p in build_providers(get_settings()):
        try:
            sessions = p.active_sessions()
            ident = p.api.get("/system/identity")
            print(f"{p.name}: OK ({ident.get('name')}), aktivních SSTP relací: {len(sessions)}")
        except Exception as e:
            ok = False
            print(f"{p.name}: CHYBA {e}", file=sys.stderr)
    return 0 if ok else 1


def cmd_notify_test(a) -> int:
    from .notify import test_message
    test_message(get_settings(), a.name)
    print("Zkušební notifikace odeslána.")
    return 0


def cmd_setup_code(a) -> int:
    from . import firstrun
    try:
        print(firstrun.CODE_FILE.read_text().strip())
    except OSError:
        raise SystemExit("průvodce neběží (controller je nastavený, nebo spusť jako root)")
    return 0


def cmd_setup_apply(a) -> int:
    import logging

    from . import firstrun
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")
    return firstrun.apply_request()


def _audit_system(action: str, after: dict) -> None:
    """Audit systémové akce; selhání auditu (DB dole) nesmí shodit zálohu."""
    try:
        from .db import operator_scope
        from .services import audit
        with operator_scope(_db()) as tx:
            audit(tx, action, target="system:backup", after=after)
    except Exception as e:  # noqa: BLE001
        print(f"audit se nezapsal: {e}", file=sys.stderr)


def _backup_plan(s) -> dict:
    from . import backupplan
    try:
        return backupplan.load(_db(), s.backup.keep)
    except Exception as e:  # noqa: BLE001 – DB dole: záloha podle výchozího plánu
        print(f"plán záloh z DB nejde načíst ({e}) – výchozí", file=sys.stderr)
        return backupplan.defaults(s.backup.keep)


def _backup_due(s, plan: dict) -> bool:
    import datetime as dt

    from . import backupplan, sysbackup
    now = dt.datetime.now().astimezone()
    last = sysbackup.listing(s.backup.dir)
    last_at = dt.datetime.fromisoformat(last[0]["at"]) if last else None
    st = sysbackup.read_status(s.paths.data_dir)
    err_at = dt.datetime.fromisoformat(st["at"]) if st.get("state") == "error" and st.get("at") else None
    return backupplan.due(plan, now, last_at, err_at)


def cmd_backup(a) -> int:
    from . import sysbackup
    from .db import PsycopgDatabase
    s = get_settings()
    req = sysbackup.request_path(s.paths.data_dir)
    reason, who = ("scheduled" if a.scheduled else "manual"), None
    if req.exists():
        try:
            who = json.loads(req.read_text()).get("user")
        except (OSError, ValueError):
            pass
        req.unlink(missing_ok=True)
        reason = "request"
    elif a.from_path:
        return 0  # path jednotka bez žádosti (už vyřízená)
    plan = _backup_plan(s)
    if reason == "scheduled" and not a.now and not _backup_due(s, plan):
        return 0  # timer běží co 15 minut, plán z administrace rozhodne
    sysbackup.write_status(s.paths.data_dir, state="running", reason=reason)
    try:
        f = sysbackup.create(s, PsycopgDatabase(s.database.migrate_dsn), reason=reason, keep=plan["keep"],
                             weekly=plan.get("weekly", 0), monthly=plan.get("monthly", 0))
    except Exception as e:  # noqa: BLE001
        sysbackup.write_status(s.paths.data_dir, state="error", error=str(e)[:500], reason=reason)
        _audit_system("system.backup_failed", {"error": str(e)[:300], "reason": reason, "by": who})
        print(f"záloha selhala: {e}", file=sys.stderr)
        return 1
    sysbackup.write_status(s.paths.data_dir, state="done", file=f.name, size=f.stat().st_size, reason=reason)
    _audit_system("system.backup", {"file": f.name, "size": f.stat().st_size, "reason": reason, "by": who})
    print(f.name)
    return 0


def _local_addrs() -> set[str]:
    """IP adresy tohoto stroje (pro kontrolu, kam vedou adresy ze zálohy)."""
    import subprocess
    try:
        out = subprocess.run(["ip", "-o", "addr", "show"], capture_output=True, timeout=10).stdout.decode()
    except (OSError, subprocess.SubprocessError):
        return set()
    return {m.group(1) for m in re.finditer(r"inet6? ([0-9a-fA-F:.]+)/", out)}


def _print_restore_report(rep: dict, has_data: bool) -> None:
    m = rep["manifest"]
    print(f"Záloha z {m.get('created_at')} · server {m.get('hostname')} · verze {m.get('app_version')} · schéma {m.get('schema')}")
    print(f"Tato instalace: verze {__version__}; po obnově poběží migrací: {rep['migrations']}")
    print(f"PostgreSQL: záloha {rep['backup_pg'] or '?'}, tento server {rep['local_pg'] or '?'}")
    for h in rep["hosts"]:
        where = "tento server" if h["here"] else (", ".join(h["resolves"]) or "nepřekládá se")
        print(f"Adresa pro zařízení/správu: {h['host']} → {where}")
    if has_data:
        print("Tento controller už má data – obnova je přepíše (před obnovou se udělá pojistná záloha).")
    for w in rep["warnings"]:
        print(f"POZOR: {w}")
    for p in rep["problems"]:
        print(f"NEJDE: {p}")
    if not rep["problems"]:
        print("Zálohu lze obnovit.")


def cmd_restore(a) -> int:
    import subprocess
    from pathlib import Path

    from . import migrate, sysbackup
    from .config import load_settings
    from .db import PsycopgDatabase, operator_scope
    s = get_settings()
    try:
        with operator_scope(_db()) as tx:
            n = tx.fetchone("SELECT count(*) AS n FROM app_user")["n"]
    except Exception:  # noqa: BLE001 – DB ještě neexistuje
        n = 0
    if n and not a.force and not a.check:
        raise SystemExit("tento controller už má data – obnova je přepíše; potvrď --force")
    pw = (Path(a.passphrase_file).read_text().strip() if a.passphrase_file
          else getpass.getpass("Heslo záloh: ").strip())
    local_pg = sysbackup.local_pg_major()
    try:
        rep = sysbackup.inspect(Path(a.file), pw, local_pg=local_pg, local_addrs=_local_addrs())
    except sysbackup.BackupError as e:
        raise SystemExit(f"zálohu nejde použít: {e}") from None
    _print_restore_report(rep, has_data=bool(n))
    if a.check:
        return 1 if rep["problems"] else 0
    if rep["problems"]:
        raise SystemExit("obnova nezačala – na systém se nesáhlo")
    if n and not a.no_safety_backup:
        # pojistka: stav, který obnova přepíše, se nejdřív zazálohuje (dosavadním heslem záloh)
        try:
            keep = len(sysbackup.listing(Path(s.backup.dir))) + 1
            f = sysbackup.create(s, PsycopgDatabase(s.database.migrate_dsn), reason="pre-restore", keep=max(keep, s.backup.keep))
        except Exception as e:  # noqa: BLE001
            raise SystemExit(f"pojistná záloha současného stavu selhala ({e}) – obnova nezačala. "
                             "Oprav příčinu, nebo ji vědomě přeskoč: --no-safety-backup") from None
        print(f"Pojistná záloha současného stavu: {f} (šifrovaná DOSAVADNÍM heslem záloh – poznamenej si ho, "
              "obnova ho nahradí heslem z obnovované zálohy)")
    units = ["mtc-web", "mtc-worker", "mtc-syslog"]
    subprocess.run(["systemctl", "stop", *units], check=False)
    try:
        res = sysbackup.restore(
            Path(a.file), pw, s, local_pg=local_pg,
            recreate_db=lambda: sysbackup.recreate_db_as_postgres(sysbackup.dbname(s.database.migrate_dsn)),
            migrate_db=lambda: migrate.upgrade(PsycopgDatabase(get_settings().database.migrate_dsn), s.database.app_role))
    except sysbackup.BackupError as e:
        subprocess.run(["systemctl", "start", *units], check=False)
        raise SystemExit(f"obnova selhala: {e}") from None
    cfg = Path("/etc/mtcontroller")
    bk = load_settings(cfg / "config.toml", environ={}).backup.passphrase_file
    import os
    fd = os.open(bk, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w") as fh:
        fh.write(pw + "\n")
    subprocess.run(["systemctl", "start", *units], check=False)
    m = res["manifest"]
    print(f"Obnoveno ze zálohy {m.get('created_at')} (verze {m.get('app_version')}, schéma {m.get('schema')}); "
          f"migrace: {res['migrated'] or 'žádné'}")
    print("Zkontroluj nginx a certifikáty (průvodce je při obnově nastaví sám): mtc-admin doctor")
    _audit_system("system.restore", {"from": m.get("created_at"), "version": m.get("app_version"),
                                     "migrated": res["migrated"]})
    return 0


def cmd_recovery_kit(a) -> int:
    from . import firstrun
    s = get_settings()
    try:
        pw = s.backup.passphrase_file.read_text().strip()
    except OSError:
        raise SystemExit("heslo záloh nejde přečíst (spusť jako root)")
    from types import SimpleNamespace
    plan = SimpleNamespace(ui_host=s.web.ui_host, mode="local" if s.tunnel.local else "remote",
                           controller_ip=s.tunnel.controller_ip)
    print(firstrun.kit_text(firstrun.kit(plan, pw)), end="")
    return 0


def _tls_log() -> None:
    import logging
    logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")


def cmd_tls(a) -> int:
    from pathlib import Path

    from . import tlscfg
    s = get_settings()
    if a.action == "status":
        st = tlscfg.status()
        if not st:
            print("certifikáty slotů nejsou (spusť jako root: mtc-admin tls own)")
        for slot, i in st.items():
            if "error" in i:
                print(f"{slot}: {i['error']}")
                continue
            print(f"{slot}: {i['kind'] or '?'} – {', '.join(i['names'])}; vydal {i['issuer']}; "
                  f"platí do {i['not_after'][:10]} ({i['days_left']} dní)")
        return 0
    _tls_log()
    if a.action == "bootstrap":
        for line in tlscfg.bootstrap(s, device_ca=s.security.device_ca_file):
            print(line)
        from . import firstrun
        if firstrun.upgrade_nginx():
            print("nginx přepnut na certifikáty /etc/ssl/mtc/{admin,checkin}")
        return 0
    req: dict = {"action": {"own": "own_ca"}.get(a.action, a.action), "slots": a.slot or list(tlscfg.SLOTS)}
    if a.action == "letsencrypt":
        if len(a.args) != 1:
            raise SystemExit("použití: mtc-admin tls letsencrypt EMAIL [--slot admin]")
        req["email"] = a.args[0]
    elif a.action == "custom":
        if len(a.args) != 2:
            raise SystemExit("použití: mtc-admin tls custom CERT.pem KEY.pem --slot admin")
        req["cert"], req["key"] = Path(a.args[0]).read_text(), Path(a.args[1]).read_text()
    try:
        res = tlscfg.apply(req, local=s.tunnel.local, hosts=tlscfg.hosts_of(s), ip=s.tunnel.controller_ip,
                           device_ca=s.security.device_ca_file)
    except Exception as e:  # noqa: BLE001
        tlscfg._audit(s, "system.tls_failed", {"error": str(e)[:300], "by": "cli"})
        raise SystemExit(f"certifikát se nepodařilo nastavit (zůstává předchozí): {e}")
    tlscfg._audit(s, "system.tls", {"action": res["action"], "slots": res["slots"], "by": "cli"})
    for w in res["warnings"]:
        print(f"POZOR: {w}")
    print(f"hotovo: {', '.join(res['slots'])} → {res['action']}")
    return 0


def cmd_nginx_repair(a) -> int:
    """Konfigurace nginx znovu z plánu průvodce (s nginx -t a návratem při chybě)."""
    from . import firstrun
    _tls_log()
    if not (firstrun.ETC / "setup-plan.json").is_file():
        raise SystemExit("chybí /etc/mtcontroller/setup-plan.json – instalace skriptem: spusť znovu deploy/install.sh")
    if firstrun.upgrade_nginx(force=True):
        print("nginx přegenerován z plánu průvodce a přenačten")
        return 0
    print("beze změny (konfigurace už odpovídá), nebo nginx -t neprošel – viz log výše", file=sys.stderr)
    return 1


def cmd_tls_apply(a) -> int:
    from . import tlscfg
    _tls_log()
    return tlscfg.apply_request(get_settings())


def cmd_netsvc_apply(a) -> int:
    """Root (mtc-netsvc.path, postinst): chrony podle Systém → Čas a DNS."""
    from . import netsvc
    _tls_log()
    return netsvc.apply_request(_db(), get_settings())


def cmd_tls_sync(a) -> int:
    from . import tlscfg
    _tls_log()
    done = tlscfg.sync()
    if done:
        tlscfg._audit(get_settings(), "system.tls_renewed", {"slots": done})
    return 0


def cmd_doctor(a) -> int:
    from . import doctor
    from .db import PsycopgDatabase
    s = get_settings()
    checks = doctor.run(s, _db(), PsycopgDatabase(s.database.migrate_dsn))
    print(doctor.render(checks))
    bad = [c for c in checks if c.status == doctor.FAIL]
    print("\nVšechno v pořádku." if not bad else f"\nProblémů: {len(bad)}")
    return 1 if bad else 0


def main(argv: list[str] | None = None) -> int:
    p = argparse.ArgumentParser(prog="mtc-admin", description=__doc__,
                                formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("migrate").set_defaults(fn=cmd_migrate)
    sub.add_parser("gen-master-key").set_defaults(fn=cmd_gen_master_key)
    x = sub.add_parser("create-superadmin"); x.add_argument("email"); x.set_defaults(fn=cmd_create_superadmin)
    x = sub.add_parser("create-user"); x.add_argument("email"); x.add_argument("role"); x.add_argument("tenant")
    x.set_defaults(fn=cmd_create_user)
    x = sub.add_parser("create-tenant"); x.add_argument("name"); x.set_defaults(fn=cmd_create_tenant)
    x = sub.add_parser("create-site"); x.add_argument("tenant"); x.add_argument("name"); x.set_defaults(fn=cmd_create_site)
    x = sub.add_parser("token"); x.add_argument("tenant"); x.add_argument("site", nargs="?"); x.set_defaults(fn=cmd_token)
    x = sub.add_parser("devices"); x.add_argument("tenant"); x.set_defaults(fn=cmd_devices)
    x = sub.add_parser("approve"); x.add_argument("tenant"); x.add_argument("device"); x.add_argument("site")
    x.add_argument("--role", default="unknown"); x.set_defaults(fn=cmd_approve)
    x = sub.add_parser("concentrator-script"); x.add_argument("name"); x.set_defaults(fn=cmd_concentrator_script)
    sub.add_parser("concentrator-check").set_defaults(fn=cmd_concentrator_check)
    x = sub.add_parser("notify-test"); x.add_argument("name"); x.set_defaults(fn=cmd_notify_test)
    sub.add_parser("doctor").set_defaults(fn=cmd_doctor)
    sub.add_parser("setup-code").set_defaults(fn=cmd_setup_code)
    sub.add_parser("setup-apply").set_defaults(fn=cmd_setup_apply)
    x = sub.add_parser("backup"); x.add_argument("--scheduled", action="store_true")
    x.add_argument("--now", action="store_true", help="hned, bez ohledu na plán")
    x.add_argument("--from-path", action="store_true"); x.set_defaults(fn=cmd_backup)
    x = sub.add_parser("restore"); x.add_argument("file"); x.add_argument("--force", action="store_true")
    x.add_argument("--check", action="store_true", help="jen posoudit zálohu, nic neměnit")
    x.add_argument("--no-safety-backup", action="store_true", help="před obnovou nezálohovat současný stav")
    x.add_argument("--passphrase-file"); x.set_defaults(fn=cmd_restore)
    sub.add_parser("recovery-kit").set_defaults(fn=cmd_recovery_kit)
    x = sub.add_parser("tls"); x.add_argument("action", nargs="?", default="status",
                                             choices=["status", "own", "letsencrypt", "custom", "bootstrap"])
    x.add_argument("args", nargs="*"); x.add_argument("--slot", action="append", choices=["admin", "checkin"])
    x.set_defaults(fn=cmd_tls)
    sub.add_parser("nginx-repair").set_defaults(fn=cmd_nginx_repair)
    sub.add_parser("tls-apply").set_defaults(fn=cmd_tls_apply)
    sub.add_parser("tls-sync").set_defaults(fn=cmd_tls_sync)
    sub.add_parser("netsvc-apply").set_defaults(fn=cmd_netsvc_apply)
    sub.add_parser("device-trust").set_defaults(fn=cmd_device_trust)
    x = sub.add_parser("device-check"); x.add_argument("tenant"); x.add_argument("device")
    x.set_defaults(fn=cmd_device_check)
    a = p.parse_args(argv)
    try:
        return a.fn(a)
    except Exception as e:  # čitelná chyba místo tracebacku
        from .services import ServiceError
        if isinstance(e, ServiceError):
            raise SystemExit(f"Chyba: {e}")
        raise


if __name__ == "__main__":
    raise SystemExit(main())
