# MikroTik Controller

> Česká verze úvodního dokumentu. Aktuální anglická verze: [README.md](../README.md).

Vlastní multi-tenant controller pro MikroTik RouterOS v7 ve stylu UniFi:
centrální správa, topologická mapa, sledování klientů, VLAN, provoz,
zálohy a firmware. Zařízení se připojují jen odchozím spojením na 443
(SSTP tunel + HTTPS check-in), takže fungují i za NATem a CGNATem.

Návrh architektury: [docs/architecture.md](architecture.md).
Instalace na Debian: [docs/install.md](install.md).

## Jak to vypadá

Snímky jsou z vestavěných testovacích dat (vymyšlená zařízení a adresy), rozhraní v angličtině.

| | |
|---|---|
| ![Mapa lokality](screenshots/map.png) **Mapa lokality** – skutečné zapojení podle bridge tabulek, porty na obou koncích, časová osa událostí | ![Seznam zařízení](screenshots/devices.png) **Zařízení** – filtry podle role, stavu, verze a modelu |
| ![Porty](screenshots/ports.png) **Porty** – rychlost, PoE, co je připojeno, chybovost s pravděpodobnou příčinou, provoz, VLAN | ![Karta bezdrátového spoje](screenshots/wireless-link.png) **Bezdrátové spoje** – provoz, signál, rychlost, ztrátovost a šum na jedné časové ose, odchylky zvýrazněné |

![Časová osa](screenshots/timeline.png)
**Časová osa** – alerty, události portů a klientů a změny konfigurace na jednom místě.

## Stav

Fáze **F0 – Základ**: připraveno k prvnímu nasazení ([testovací plán](test-plan.md)).

- [x] Instalace na Debian 13 jen z apt (`deploy/install.sh`), systemd sandbox, nginx
- [x] Multi-tenant datový model, row-level security, append-only audit
- [x] Admin UI + API: přihlášení, povinné TOTP MFA, zamykání účtu, CSRF, role per tenant, správa uživatelů, změna hesla, reset MFA
- [x] Adopce jedním řádkem v terminálu MikroTiku, schválení v UI
- [x] Check-in přes HTTPS, fronta příkazů s potvrzením (provisioning, restart, odebrání)
- [x] SSTP tunel na každé zařízení, účty na koncentrátoru přes REST s pinningem certifikátu
- [x] Ověření adopce přes REST v tunelu, offline detekce, failover mezi koncentrátory
- [x] Generátor konfigurace koncentrátoru (`mtc-admin concentrator-script`)
- [x] Inventura přes REST (jen čtení), metriky rozhraní (5 min / hodinové agregace), grafy provozu v UI
- [x] Zálohy konfigurace (šifrovaně), drift, diff se skrytými hesly
- [x] Analýza VLAN/bridge proti cílovému modelu + náhled migrace
- [x] Modul NTP s plány změn (observe/manage, schválení, zneplatnění)
- [x] Infrastruktura lokality jako v UniFi 10 (WAN → gateway → switche → AP, porty na spojích, STP root, CPU/RAM)
- [x] Topologie lokality (MNDP/LLDP), dostupné aktualizace RouterOS, známé problémy verzí
- [x] Aktualizace RouterOS a RouterBOOT z UI (potvrzená verze, blokace kritických verzí, kontrola výsledku)
- [x] Postupná aktualizace lokality (okraj → gateway, po jednom, zastavení při chybě)
- [x] Release notes: changelogy mezilehlých verzí, změny relevantní pro konkrétní zařízení
- [x] `mtc-admin doctor` – kontrola instalace
- [ ] Vlastní CA a klientské certifikáty pro SSTP
- [x] Klienti lokality (DHCP/ARP/bridge host/wifi) s polohou na portu/AP, historie 90 dní, hledání napříč lokalitami
- [x] Bezpečnostní audit konfigurace zařízení (hardening podle doporučení MikroTiku, kritické nálezy → alert)
- [x] Sítě lokality (VLAN, podsítě, DHCP server/relay, leases) a nastavení bridgů
- [x] DHCP leases a statické IP: rezervace, DHCP options per klient, výrobce podle MAC, poznámky, mapa adres, konflikty
- [x] Ochrana proti cizím DHCP: DHCP snooping s trusted porty podle cesty k DHCP serveru, DHCP alert
- [x] Plán kanálů Wi-Fi lokality (obdoba Channel AI, bez RF skenu) se skutečným kanálem rádií
- [x] Loop protect: smyčky na portech (alert, skóre, editor portu)
- [x] Panel portů jako UniFi: připojená zařízení s ikonou, tabulka portů, skóre anomálie za 24 h, jména a podsítě VLAN
- [x] Změny portů jako Port Manager (PVID, tagované VLAN, PoE, edge, zapnutí, restart PoE) s automatickým návratem (commit-confirm) a profily portů
- [x] Historie portů (Time Machine): linka, výpadky, rychlost, PoE, VLAN, STP, sousedé – 90 dní
- [x] Porty (rychlost, duplex, SFP, PoE, VLAN, STP role) a STP lokality (root, blokované porty, rizika smyček)
- [x] Wi-Fi lokality: rádia (wifi i wireless), SSID, kanály, klienti, signál, CAPsMAN AP, varování
- [x] Alerty (offline, tunel, REST, certifikát, CPU/paměť, porty, zálohy, verze) a notifikace (webhook, Nextcloud Talk, e-mail)
- [x] Firewall jako zóny (UniFi zone-based): matice zón, pravidla filtru a NAT s počty paketů – jen čtení
- [ ] VLAN správa (aplikace migrace), správa SSID/CAPsMAN, PtP, úpravy firewallu

Mapování funkcí UniFi: [docs/unifi-parity.md](unifi-parity.md).

## Struktura

```
src/mtcontroller/
  config.py        konfigurace (config.toml + MTC_* proměnné)
  db.py            psycopg, tenant_scope / operator_scope pro RLS
  migrate.py       migrátor; SQL schéma v sql/NNNN_*.up.sql
  services.py      tenanti, adopce, schválení, check-in, fronta příkazů
  auth.py, totp.py přihlášení, MFA, relace, role
  routeros.py      generování RouterOS skriptů (adopce, provisioning, příkazy)
  rosapi.py        REST klient RouterOS s pinningem certifikátu
  concentrator.py  konfigurace koncentrátoru
  security.py      hesla, tokeny, šifrování tajemství
  ipam.py          tunelové adresy
  tunnel/          abstrakce koncentrátoru (MikroTik, později RADIUS)
  web/             Starlette: admin UI + API, check-in (oddělené podle hostname)
  worker/          offline detekce, ověření adopce, dorovnání koncentrátorů
  cli.py           mtc-admin
deploy/            install.sh, systemd unity, nginx
tests/             pytest (i end-to-end proti Postgresu) + tests/db (kontroly schématu)
```

## Vývoj

```sh
apt install python3-starlette python3-uvicorn python3-psycopg python3-pydantic \
            python3-cryptography python3-pytest postgresql ieee-data
# testy s DB potřebují trust autentizaci na unix socketu (jen vývojový stroj!)
sudo -u postgres tests/db/run.sh   # kontroly schématu (RLS, audit, tokeny)
python3 -m pytest                  # unit + end-to-end testy (bez DB se přeskočí)
```

## Licence

GNU Affero General Public License verze 3 – viz [LICENSE](../LICENSE). Bez záruky. Kdo provozuje
upravenou verzi jako síťovou službu, musí jejím uživatelům nabídnout zdrojový kód.
